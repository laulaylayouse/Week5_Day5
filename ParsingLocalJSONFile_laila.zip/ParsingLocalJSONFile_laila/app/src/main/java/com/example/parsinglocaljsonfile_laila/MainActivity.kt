package com.example.parsinglocaljsonfile_laila

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONArray
import java.io.IOException
import java.io.InputStream

class MainActivity : AppCompatActivity() {

    lateinit var Recycler_View: RecyclerView

    var Details_List = arrayListOf<Details>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Recycler_View = findViewById(R.id.Recycler_View)


        var json: String? = null
        try {
            val inputStream: InputStream = assets.open("data.json")
            json = inputStream.bufferedReader().use { it.readText() }

            var jsonarr = JSONArray(json)

            for (i in 0 until jsonarr.length()) {
                var jsonobj = jsonarr.getJSONObject(i)

                Details_List.add(Details(jsonobj.getString("url"), jsonobj.getString("title")))
            }
            Recycler_View.adapter = Adapter(Details_List)
            Recycler_View.layoutManager = LinearLayoutManager(this)

        } catch (e: IOException) {

        }

    }
}